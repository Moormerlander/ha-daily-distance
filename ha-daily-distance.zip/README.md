# Tageskilometer für Home Assistant

Version 0.2

Eine lokale Home-Assistant-Custom-Integration, die einen Sensor in **km/h** zeitlich integriert und daraus gefahrene Kilometer berechnet.

## Funktionen

- beliebiger Home-Assistant-Geschwindigkeitssensor als Quelle
- 1-Sekunden-Updates werden sauber verarbeitet
- Mindestgeschwindigkeit konfigurierbar, Standard 1 km/h
- Tageswechsel konfigurierbar, Standard 00:00
- Tageskilometer heute
- Tageskilometer gestern
- Tageskilometer Woche
- Tageskilometer Monat
- Tageskilometer Jahr
- Tageskilometer Gesamt
- persistente Speicherung über Neustarts
- tägliche Werte der letzten 30 Tage als Attribut des Sensors „Tageskilometer Heute"
- Home-Assistant-Langzeitstatistik-kompatible Distanzsensoren
- Datenlücken von mehr als 5 Minuten werden nicht als gefahrene Strecke interpretiert

## Installation

### HACS

Das GitHub-Repository als Custom Repository vom Typ **Integration** hinzufügen und anschließend installieren.

Die Integration ist nicht auf ein bestimmtes Fahrzeug oder einen bestimmten Sensor festgelegt. Bei der Einrichtung kann jede `sensor.*`-Entity ausgewählt oder manuell eingetragen werden, die ihre Geschwindigkeit in km/h liefert.

### Manuell

Den Ordner `custom_components/tageskilometer` nach `/config/custom_components/tageskilometer` kopieren und Home Assistant neu starten.

## Einrichtung

Einstellungen → Geräte & Dienste → Integration hinzufügen → **Tageskilometer**

Für das Wohnmobil als Geschwindigkeitssensor:

`sensor.gps_speed_kmh`

Empfohlener Startwert für die Mindestgeschwindigkeit: **1,0 km/h**.
