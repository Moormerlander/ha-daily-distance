from __future__ import annotations

from datetime import time

DOMAIN = "tageskilometer"
CONF_SPEED_SENSOR = "speed_sensor"
CONF_MIN_SPEED = "min_speed"
CONF_RESET_TIME = "reset_time"

DEFAULT_MIN_SPEED = 1.0
DEFAULT_RESET_TIME = time(0, 0)
STORE_VERSION = 1
STORE_KEY_PREFIX = "tageskilometer"

ATTR_SPEED_SENSOR = "speed_sensor"
ATTR_MIN_SPEED = "min_speed"
