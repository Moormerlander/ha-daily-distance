from __future__ import annotations

from collections.abc import Callable
from datetime import datetime, time, timedelta
import logging
from typing import Any

from homeassistant.core import Event, HomeAssistant, callback
from homeassistant.helpers.event import async_track_state_change_event, async_track_time_change
from homeassistant.helpers.storage import Store

from .const import CONF_MIN_SPEED, CONF_RESET_TIME, CONF_SPEED_SENSOR, STORE_KEY_PREFIX, STORE_VERSION

_LOGGER = logging.getLogger(__name__)


class TageskilometerManager:
    """Integrates a km/h sensor into daily distance totals."""

    def __init__(self, hass: HomeAssistant, entry_id: str, config: dict[str, Any]) -> None:
        self.hass = hass
        self.entry_id = entry_id
        self.speed_sensor = config[CONF_SPEED_SENSOR]
        self.min_speed = float(config[CONF_MIN_SPEED])
        self.reset_time = self._parse_time(config[CONF_RESET_TIME])
        self.store = Store(hass, STORE_VERSION, f"{STORE_KEY_PREFIX}.{entry_id}")
        self._unsub_state: Callable[[], None] | None = None
        self._unsub_time: Callable[[], None] | None = None
        self._listeners: list[Callable[[], None]] = []
        self._data: dict[str, Any] = {
            "days": {},
            "total_km": 0.0,
            "last_timestamp": None,
            "last_speed": 0.0,
        }
        self._current_day: str | None = None

    @staticmethod
    def _parse_time(value: time | str) -> time:
        if isinstance(value, time):
            return value
        return time.fromisoformat(value)

    async def async_load(self) -> None:
        stored = await self.store.async_load()
        if isinstance(stored, dict):
            self._data.update(stored)
        self._current_day = self._day_key(datetime.now().astimezone())
        self._prune_days()

    def _day_key(self, dt: datetime) -> str:
        """Return the logical day key, respecting the configured reset time."""
        local = dt.astimezone()
        boundary = local.replace(hour=self.reset_time.hour, minute=self.reset_time.minute, second=self.reset_time.second, microsecond=0)
        if local < boundary:
            local -= timedelta(days=1)
        return local.date().isoformat()

    def _prune_days(self) -> None:
        days = self._data.setdefault("days", {})
        if len(days) > 400:
            for key in sorted(days)[:-400]:
                days.pop(key, None)

    async def async_start(self) -> None:
        self._unsub_state = async_track_state_change_event(
            self.hass, [self.speed_sensor], self._async_speed_changed
        )
        self._unsub_time = async_track_time_change(
            self.hass, self._async_reset_tick, hour=self.reset_time.hour, minute=self.reset_time.minute, second=self.reset_time.second
        )

    async def async_stop(self) -> None:
        if self._unsub_state:
            self._unsub_state()
            self._unsub_state = None
        if self._unsub_time:
            self._unsub_time()
            self._unsub_time = None
        await self.async_save()

    async def async_save(self) -> None:
        await self.store.async_save(self._data)

    def add_listener(self, listener: Callable[[], None]) -> Callable[[], None]:
        self._listeners.append(listener)
        return lambda: self._listeners.remove(listener) if listener in self._listeners else None

    @callback
    def _notify(self) -> None:
        for listener in tuple(self._listeners):
            listener()

    async def _async_reset_tick(self, now: datetime) -> None:
        new_day = self._day_key(now)
        if new_day != self._current_day:
            self._current_day = new_day
            self._data["last_timestamp"] = None
            self._data["last_speed"] = 0.0
            await self.async_save()
            self._notify()

    async def _async_speed_changed(self, event: Event) -> None:
        new_state = event.data.get("new_state")
        if new_state is None:
            return
        try:
            speed = float(new_state.state)
        except (TypeError, ValueError):
            self._data["last_timestamp"] = None
            self._data["last_speed"] = 0.0
            return
        if speed < 0:
            return

        now = datetime.now().astimezone()
        day_key = self._day_key(now)
        if day_key != self._current_day:
            self._current_day = day_key
            self._data["last_timestamp"] = None
            self._data["last_speed"] = 0.0

        timestamp = now.timestamp()
        last_ts = self._data.get("last_timestamp")
        last_speed = float(self._data.get("last_speed", 0.0))

        # A gap of more than 5 minutes is treated as a data gap, not as driving.
        if last_ts is not None:
            elapsed = timestamp - float(last_ts)
            if 0 < elapsed <= 300:
                effective_speed = speed if speed >= self.min_speed else 0.0
                previous_speed = last_speed if last_speed >= self.min_speed else 0.0
                distance_km = ((previous_speed + effective_speed) / 2.0) * elapsed / 3600.0
                if distance_km > 0:
                    self._data["days"][day_key] = float(self._data["days"].get(day_key, 0.0)) + distance_km
                    self._data["total_km"] = float(self._data.get("total_km", 0.0)) + distance_km
                    self._prune_days()
                    self._notify()
                    await self.async_save()

        self._data["last_timestamp"] = timestamp
        self._data["last_speed"] = speed

    def _value_for_day(self, day_key: str) -> float:
        return float(self._data.get("days", {}).get(day_key, 0.0))

    def _day_keys(self, now: datetime, count: int) -> list[str]:
        current = datetime.fromisoformat(self._current_day + "T00:00:00") if self._current_day else now.replace(hour=0, minute=0, second=0, microsecond=0)
        return [(current - timedelta(days=i)).date().isoformat() for i in range(count)]

    def value_today(self) -> float:
        return self._value_for_day(self._current_day or self._day_key(datetime.now().astimezone()))

    def value_yesterday(self) -> float:
        keys = self._day_keys(datetime.now().astimezone(), 2)
        return self._value_for_day(keys[1])

    def value_period(self, days: int) -> float:
        return sum(self._value_for_day(key) for key in self._day_keys(datetime.now().astimezone(), days))

    def value_total(self) -> float:
        return float(self._data.get("total_km", 0.0))

    def daily_values(self, days: int = 30) -> dict[str, float]:
        keys = list(reversed(self._day_keys(datetime.now().astimezone(), days)))
        return {key: round(self._value_for_day(key), 3) for key in keys}
