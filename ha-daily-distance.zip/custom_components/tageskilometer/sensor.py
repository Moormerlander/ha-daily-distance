from __future__ import annotations

from datetime import datetime
from typing import Callable

from homeassistant.components.sensor import SensorDeviceClass, SensorEntity, SensorStateClass
from homeassistant.config_entries import ConfigEntry
from homeassistant.const import UnitOfLength
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity import DeviceInfo

from .const import DOMAIN
from .coordinator import TageskilometerManager


SENSORS = (
    ("heute", "Tageskilometer Heute", "today"),
    ("gestern", "Tageskilometer Gestern", "yesterday"),
    ("woche", "Tageskilometer Woche", "week"),
    ("monat", "Tageskilometer Monat", "month"),
    ("jahr", "Tageskilometer Jahr", "year"),
    ("gesamt", "Tageskilometer Gesamt", "total"),
)


async def async_setup_entry(hass: HomeAssistant, entry: ConfigEntry, async_add_entities) -> None:
    manager: TageskilometerManager = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([TageskilometerSensor(manager, entry, key, name, value_type) for key, name, value_type in SENSORS])


class TageskilometerSensor(SensorEntity):
    _attr_native_unit_of_measurement = UnitOfLength.KILOMETERS
    _attr_device_class = SensorDeviceClass.DISTANCE
    _attr_state_class = SensorStateClass.TOTAL_INCREASING
    _attr_icon = "mdi:map-marker-distance"
    _attr_should_poll = False

    def __init__(self, manager: TageskilometerManager, entry: ConfigEntry, key: str, name: str, value_type: str) -> None:
        self.manager = manager
        self._attr_name = name
        self._attr_unique_id = f"{entry.entry_id}_{key}"
        self._value_type = value_type
        if value_type == "yesterday":
            self._attr_state_class = SensorStateClass.MEASUREMENT
        self._remove_listener: Callable[[], None] | None = None
        self._attr_device_info = DeviceInfo(
            identifiers={(DOMAIN, entry.entry_id)},
            name="Tageskilometer",
            manufacturer="Custom",
            model="Geschwindigkeitsbasierter Tageskilometerzähler",
        )

    async def async_added_to_hass(self) -> None:
        self._remove_listener = self.manager.add_listener(self._handle_update)

    async def async_will_remove_from_hass(self) -> None:
        if self._remove_listener:
            self._remove_listener()
            self._remove_listener = None

    @property
    def native_value(self) -> float:
        if self._value_type == "today":
            return round(self.manager.value_today(), 3)
        if self._value_type == "yesterday":
            return round(self.manager.value_yesterday(), 3)
        if self._value_type == "week":
            return round(self.manager.value_period(7), 3)
        if self._value_type == "month":
            now = datetime.now().astimezone()
            start = datetime(now.year, now.month, 1, tzinfo=now.tzinfo)
            return round(sum(self.manager._value_for_day(d.isoformat()) for d in self._dates_between(start, now)), 3)
        if self._value_type == "year":
            now = datetime.now().astimezone()
            start = datetime(now.year, 1, 1, tzinfo=now.tzinfo)
            return round(sum(self.manager._value_for_day(d.isoformat()) for d in self._dates_between(start, now)), 3)
        return round(self.manager.value_total(), 3)

    @staticmethod
    def _dates_between(start: datetime, end: datetime):
        current = start.date()
        last = end.date()
        from datetime import timedelta
        while current <= last:
            yield current
            current += timedelta(days=1)

    @property
    def extra_state_attributes(self):
        attrs = {
            "geschwindigkeitssensor": self.manager.speed_sensor,
            "mindestgeschwindigkeit_kmh": self.manager.min_speed,
            "resetzeit": self.manager.reset_time.strftime("%H:%M:%S"),
        }
        if self._value_type == "today":
            attrs["tageswerte_letzte_30_tage"] = self.manager.daily_values(30)
        return attrs

    def _handle_update(self) -> None:
        self.async_write_ha_state()
